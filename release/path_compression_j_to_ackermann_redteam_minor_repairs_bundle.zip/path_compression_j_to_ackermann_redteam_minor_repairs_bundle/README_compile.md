# Compile instructions

This bundle contains the paper-style LaTeX version of the accepted path-compression proof-digestion note.

## Standard compile command

```bash
latexmk -pdf path_compression_j_to_ackermann.tex
```

## Manual compile command

```bash
pdflatex path_compression_j_to_ackermann.tex
bibtex path_compression_j_to_ackermann
pdflatex path_compression_j_to_ackermann.tex
pdflatex path_compression_j_to_ackermann.tex
```

## Container note

The PDF in this bundle was compiled successfully in the working container with:

```bash
pdflatex -interaction=nonstopmode path_compression_j_to_ackermann.tex
/usr/bin/bibtex.original path_compression_j_to_ackermann
pdflatex -interaction=nonstopmode path_compression_j_to_ackermann.tex
pdflatex -interaction=nonstopmode path_compression_j_to_ackermann.tex
```

The local `bibtex` symlink was unavailable in the container, but `/usr/bin/bibtex.original` was present. On a normal TeX installation, the standard `bibtex` command should work.

## Files

- `path_compression_j_to_ackermann.tex`: LaTeX article source.
- `path_compression_j_to_ackermann.bib`: bibliography source.
- `path_compression_j_to_ackermann.bbl`: generated bibliography file from the verified compile.
- `path_compression_j_to_ackermann.pdf`: compiled PDF.
- `compile_report.md`: compile summary.
- `compile_report.log`: raw compile transcript.
- `paper_conversion_audit.md`: polish/conversion audit.
- `integer_threshold_patch_report.md`: record of the integer-threshold precision patch.
